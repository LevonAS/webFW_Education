<div id="sidebar_container">
    <div class="sidebar">
        <div class="sidebar_top"></div>
        <div class="sidebar_item">
            <!-- insert your sidebar items here -->
            <h3>Latest News</h3>
            <h4>New Website Launched</h4>
            <h5>2023</h5>
            <p>2023 sees the redesign of our website. Take a look around and let us know what you think.<br /><a href="#">Read more</a></p>
        </div>
        <div class="sidebar_base"></div>
    </div>
    <div class="sidebar">
        <div class="sidebar_top"></div>
        <div class="sidebar_item">
            <h3>Useful Links</h3>
            <ul>
                <li><a href="/create-category/">Создать новую категорию</a>
                <li><a href="/category-list/">Список категорий</a></li>
                <li><a href="/courses-list/?id=0">Список курсов</a></li>
                <li><a href="/create-course/">Создать курс</a></li>
            </ul>
        </div>
        <div class="sidebar_base"></div>
    </div>
    <div class="sidebar">
        <div class="sidebar_top"></div>
        <div class="sidebar_item">
            <h3>Search</h3>
            <form method="post" action="#" id="search_form">
                <p>
                    <input class="search" type="text" name="search_field" value="Enter keywords....." />
                    <input name="search" type="button"   alt="Search" title="Search" />
                </p>
            </form>
        </div>
        <div class="sidebar_base"></div>
    </div>
</div>