import re


def email_parse(email):
    pattern = r"(^[a-zA-Z0-9_.'-]+@[a-zA-Z0-9.-]+\.[a-zA-Z.]{2,4}$)"
    number_re = re.compile(pattern)
    print("number_re: ", number_re)
    print("re.findall: ", re.findall(number_re, in_email))
    if re.findall(number_re, in_email):
        parse = re.split(r'@', email)
        res_dict['username'] = parse[0]
        res_dict['domain'] = parse[1]
        return res_dict
    else:
        raise ValueError('Ошибка в написании email-адреса')


res_dict = {
    'username' : '',
    'domain' : ''
 }


in_email = '8some_one@geek-brainsru'
#
if __name__ == '__main__':
    print('Извлечённые данные:\n ', email_parse(in_email))