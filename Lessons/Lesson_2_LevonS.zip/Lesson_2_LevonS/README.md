# webFW_Education
Обучающий курс "Архитектура и шаблоны проектирования на Python" от GeekBrains (2023г).

### Запуск проекта
Находясь в рабочей директории проекта Lesson_X_LevonS/ запустить:
  python run.py

### Окружение разработки
- jinja2-3.1.2;
- python 3.10.6;
- vUbuntu Server 22_04.

## Лицензия
MIT
